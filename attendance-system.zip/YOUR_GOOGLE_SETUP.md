# 🎉 Google OAuth Activation Guide
**Your Google credentials are ready! Follow these steps to complete the setup.**

---

## ✅ **Your Google OAuth Credentials**

**Project ID:** `axiomatic-skill-272411`
**Client ID:** `201096018715-03p6la4pckrhkdbeub7ekadest05o01h.apps.googleusercontent.com`
**Client Secret:** `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`

✅ **Status:** Credentials configured in `.env.local`

---

## 🚀 **Next Steps to Complete Setup**

### **Step 1: Configure Supabase (5 minutes)**

1. **Go to your Supabase Dashboard:**
   - Visit: https://supabase.com/dashboard
   - Select your project

2. **Enable Google Provider:**
   - Navigate to **Authentication** → **Providers**
   - Find **Google** in the list
   - Toggle **\"Enable sign in with Google\"** to **ON**

3. **Enter Google Credentials:**
   ```
   Client ID: 201096018715-03p6la4pckrhkdbeub7ekadest05o01h.apps.googleusercontent.com
   Client Secret: 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
   ```
   - Click **\"Save\"**

4. **Configure Redirect URLs:**
   - Go to **Authentication** → **URL Configuration**
   - Set **Site URL:** `http://localhost:3000` (for development)
   - Add **Redirect URLs:**
     ```
     http://localhost:3000/auth/callback
     http://localhost:3000/**
     ```
   - Click **\"Save\"**

### **Step 2: Update Google Console (Required)**

⚠️ **Important:** You need to add your actual Supabase URL to Google Console

1. **Go to Google Cloud Console:**
   - Visit: https://console.cloud.google.com/
   - Select project: `axiomatic-skill-272411`

2. **Update OAuth 2.0 Client:**
   - Go to **APIs & Services** → **Credentials**
   - Find your OAuth 2.0 client ID
   - Click **Edit** (pencil icon)

3. **Update Redirect URIs:**
   Replace `https://your-supabase-project.supabase.co/auth/v1/callback` with your actual Supabase URL:
   ```
   http://localhost:3000/auth/callback
   https://YOUR_ACTUAL_SUPABASE_PROJECT_ID.supabase.co/auth/v1/callback
   ```
   
   **To find your Supabase URL:**
   - Go to your Supabase project settings
   - Copy the project URL (looks like: `https://abcdefg.supabase.co`)
   - Add `/auth/v1/callback` to the end

4. **Save changes**

### **Step 3: Add Your Supabase Credentials**

Update your `.env.local` file with your actual Supabase credentials:

```env
# Replace these with your actual Supabase values
NEXT_PUBLIC_SUPABASE_URL=https://YOUR_PROJECT_ID.supabase.co
NEXT_PUBLIC_SUPABASE_ANON_KEY=YOUR_ANON_KEY_HERE
SUPABASE_SERVICE_ROLE_KEY=YOUR_SERVICE_ROLE_KEY_HERE
```

**To get these values:**
1. Go to Supabase Dashboard → Your Project
2. Click **Settings** → **API**
3. Copy:
   - **Project URL** → `NEXT_PUBLIC_SUPABASE_URL`
   - **Anon public key** → `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - **Service role key** → `SUPABASE_SERVICE_ROLE_KEY`

---

## 🧪 **Testing Your Setup**

### **Step 1: Start Development Server**
```bash
npm run dev
```

### **Step 2: Test Google Authentication**
1. Open: http://localhost:3000
2. Look for **\"متابعة بحساب جوجل\"** (Continue with Google) button
3. Click the Google sign-in button
4. Complete Google authentication
5. Check if user profile is created in Supabase

### **Expected Flow:**
1. ✅ Google button appears
2. ✅ Clicking opens Google popup/redirect
3. ✅ User signs in with Google account
4. ✅ User is redirected back to your app
5. ✅ Profile created in Supabase `profiles` table
6. ✅ User logged into dashboard

---

## 🔧 **Current Configuration Status**

- ✅ **Google Credentials:** Configured in `.env.local`
- ⏳ **Supabase Integration:** Needs your Supabase credentials
- ⏳ **Google Console:** Needs actual Supabase URL
- ⏳ **Testing:** Ready after above steps

---

## 🚨 **Troubleshooting**

### **Error: \"redirect_uri_mismatch\"**
**Solution:** 
1. Check that redirect URIs in Google Console include your actual Supabase URL
2. Make sure URLs match exactly (including `https://` and `/auth/v1/callback`)

### **Error: \"OAuth provider not configured\"**
**Solution:**
1. Verify Google provider is enabled in Supabase
2. Check that Client ID and Secret are entered correctly
3. Restart your development server

### **Error: \"Supabase not configured\"**
**Solution:**
1. Add your actual Supabase credentials to `.env.local`
2. Restart development server: `npm run dev`

### **Google button doesn't appear**
**Solution:**
1. Check browser console for errors
2. Verify environment variables are loaded
3. Make sure Supabase is properly configured

---

## 📱 **For Production Deployment**

When deploying to Vercel:

1. **Add environment variables to Vercel:**
   - All variables from `.env.local`
   - Update `NEXTAUTH_URL` to your Vercel URL

2. **Update Google Console:**
   - Add your Vercel URL to JavaScript origins
   - Add your Vercel callback URL to redirect URIs

3. **Update Supabase:**
   - Add your Vercel URL to redirect URLs
   - Update site URL if needed

---

## ✅ **Quick Checklist**

- [ ] Google credentials added to `.env.local` ✅
- [ ] Supabase credentials added to `.env.local`
- [ ] Google provider enabled in Supabase
- [ ] Google Console redirect URIs updated with actual Supabase URL
- [ ] Development server restarted
- [ ] Google sign-in button appears
- [ ] Authentication flow works end-to-end

---

## 📞 **Need Help?**

**Quick Debug Commands:**
```javascript
// Check if Google is configured (in browser console)
console.log('Google Client ID:', process.env.NEXT_PUBLIC_GOOGLE_CLIENT_ID)

// Check Supabase configuration
console.log('Supabase URL:', process.env.NEXT_PUBLIC_SUPABASE_URL)
```

**Common Issues:**
1. **Missing Supabase credentials** → Add them to `.env.local`
2. **Wrong redirect URIs** → Update Google Console with actual URLs
3. **Google provider disabled** → Enable in Supabase dashboard

---

**🎯 After completing these steps, users will be able to sign in with Google seamlessly!**

**📧 Your Google project `axiomatic-skill-272411` is ready to go!**"